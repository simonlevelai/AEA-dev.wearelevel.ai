const { dataRetentionHealthCheck } = require('../dist/functions/DataRetentionCleanupFunction');

module.exports = async function (context, req) {
    context.log('🏥 Health check requested at', new Date().toISOString());
    
    try {
        const healthStatus = await dataRetentionHealthCheck(context);
        context.res = {
            status: healthStatus.status === 'healthy' ? 200 : 500,
            body: healthStatus,
            headers: {
                'Content-Type': 'application/json'
            }
        };
        context.log('✅ Health check completed:', healthStatus.status);
    } catch (error) {
        context.log.error('❌ Health check failed:', error);
        context.res = {
            status: 500,
            body: { 
                status: 'unhealthy',
                error: error.message || 'Unknown error',
                timestamp: new Date().toISOString()
            },
            headers: {
                'Content-Type': 'application/json'
            }
        };
    }
};
